---
layout: page
title: Projects
---

### Cloudfox Services
- HubSpot system implementation
- Xero, Stripe & PMS integrations
- Reporting & automation

### SaaS Platform (Alpha)
- Multi-tenant analytics tools for landlords
- Built on Supabase + Stripe + Next.js
