---
layout: page
title: About Me
---

I'm Eddie Lee — co-founder of Cloudfox Group Ltd and a systems thinker at heart.

Cloudfox helps property managers get the most out of their software stack. I focus on clean setup, automation, and scalable processes.
